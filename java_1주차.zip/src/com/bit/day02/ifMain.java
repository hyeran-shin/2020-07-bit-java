package com.bit.day02;

public class ifMain {
	public static void main(String[] args) {
		
	}

}
