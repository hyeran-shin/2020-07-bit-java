package com.bit.day02.prob;


public class PowerOfTwo {
	public static void main(String[] args) {
		// Q. 2의 제곱수 값을 구하는 while 반복문을 작성하세요.
		// 2의 4제곱수 = 2*2*2*2 = 16
		/*
		 * System.out.println("제곱수 입력 : "); Scanner scan = new Scanner(System.in); //int
		 * two = scan.nextInt(); int i = 2; int sum = 1;
		 * 
		 * while (true) { // i = 1,2,3,4 two = 4 // i *= two; //System.out.println(i);
		 * if (i == 5) { break; } i++; } // System.out.println("2의 " + two + "제곱수 : " +
		 * sum);
		 * 
		 * scan.close(); ///////////////////// long a = 2; long n = 10;
		 * 
		 * long result = 1;
		 * 
		 * while (n > 0) { if (n % 2 == 1) result *= a; a = a * a; n /= 2;
		 * System.out.print("result = " + result + " " + a); }
		 */
	}
}
