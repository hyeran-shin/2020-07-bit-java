package com.bit.day07.prob;

public class Program {
	public static void main(String[] args) {
		Manager m = new Manager();
		m.process();

	}
}
