package com.bit.day07.vector;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Manager m = new Manager();
		m.process();
	}

}
