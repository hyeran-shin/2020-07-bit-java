package com.bit.day05.cast;

// super class
public class Parent { 
	String name;
	int age;
	
	Parent(){
		name = "부모";
		age = 60;
	}
	
	void info() {
		System.out.println("부모 클래스 info() 메소드 호출됨...");
	}

	
}
    