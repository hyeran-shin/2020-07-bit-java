package com.bit.day05.abs;

public class Dog extends Animal{
	public void eat() {
		System.out.println("강아지 와구와구");
	}
}
