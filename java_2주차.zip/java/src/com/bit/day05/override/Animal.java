package com.bit.day05.override;

public class Animal {

	public void eat() {
		System.out.println("동물이 밥을 먹습니다.");
	}
	
}
