package com.bit.day01;


public class Hello {
	//main : 프로그램의 시작점
	// -> JVM에 의해 호출되어 수행된다.
	// -> main의 역할이 끝나더라도 프로그램의 종료로 이어지지 않을 수 있다.
	public static void main(String[] args) {
		System.out.println("dd hhihihihihihihihihihihihihihihihi");
	}
}
