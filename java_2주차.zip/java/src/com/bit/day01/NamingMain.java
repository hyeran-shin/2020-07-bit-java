package com.bit.day01;

public class NamingMain {
	//JAVA Annotation
	// ->@SuppressWarnings : 컴파일러야 해당 경고를 무시해라.
	@SuppressWarnings("unused")
	public static void main(String[] args) {

		//낙타의 등(camelCase)
		//단어의 의미가 바뀌는 시점의 첫 문자를 대문자
		int sumOfTOtalMoney;
		
		int totalmoney;
		int total_money;
		//뱀이 기어가는 모양(snake_case)
		//_를 이용하여 구분
		
		int num;
		//헝가리안ㅅ기 표기법
		int iNum;
		//kebob-case
		// '-'를 활용하여 단어의 의미를 구분
		//data-cb, my-board
		//HTML에서 속성의 이름을 지을 때 주로 활용
	}
}
