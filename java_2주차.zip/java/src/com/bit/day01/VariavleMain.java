package com.bit.day01;

public class VariavleMain {
	public static void main(String[] args) {
		int num;
		num=10;
		System.out.println(num);
		
		int a=20;
		System.out.println(a);
		
		//20 자체도 데이터
		//이름없는 상수 데이터(리터럴 상수)
		//정수형 리터럴 상수의 기본 타입은 int
		//CPU는 int 형의 데이터의 크기만 연상 가능
		//연산 직전에 short형 데이터는 int 형으로 형 변환
		//변환 연산의 과정이 추가로 동작한다.
		//속도보다 데이터의 양이 중요 시 되는 상황도 존재
		//데이터의 크기 성격이 강하다면 short,byte 활용
		
		
	}
}
